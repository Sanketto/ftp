#!/bin/bash

yellow_on="$(tput setaf 220)$(tput smso)"  
yellow_off=$(tput sgr0)
green_on=$(tput setaf 118)$(tput smso)  
green_off=$(tput sgr0)
sudo rm /var/lib/dpkg/lock
sudo rm /var/lib/apt/lists/lock
sudo rm /var/lib/dpkg/lock-frontend
sudo rm /var/cache/apt/archives/lock
sudo rm -r /etc/apt/sources.list.d/*


GEN_ENV_PROXY='http_proxy="http://127.0.0.1:27001"
https_proxy="http://127.0.0.1:27001"'
GEN_APT_PROXY='Acquire::http::proxy "http://127.0.0.1:27001";
Acquire::https::proxy "http://127.0.0.1:27001";'

PANA_ENV_PROXY='http_proxy="http://10.77.8.70:8080"
https_proxy="http://10.77.8.70:8080"'
PANA_APT_PROXY='Acquire::http::proxy "http://10.77.8.70:8080";
Acquire::https::proxy "http://10.77.8.70:8080";'

zscaler="Zscaler-linux-1.5.0.41-installer.run"
mcAfeeTP="McAfeeTP-10.7.17-66-Release-standalone.tar.gz"
#mcAfeeFW="McAfeeFW-10.7.17-50-Release-standalone.tar.gz"
trellix="install-trellix.sh"
cortex="cortex-8.6.0.127790.deb"
chrome="google-chrome-stable_current_amd64.deb"
gp5="GlobalProtect_UI_deb-5.1.4.0-9.deb"
gp6="GlobalProtect_UI_focal_deb-6.1.0.0-44.deb"
msEdge="microsoft-edge-stable_123.0.2420.81-1_amd64.deb"
linuxDomain="LinuxDomainJoinUpdated.sh"
asfp="asfp-2023.2.1.20-linux.deb"
gtb20="GTBEndpointAgent-15.19.1.41521.TCP.ubuntu20.04.amd64.deb"
gtb22="GTBEndpointAgent-15.19.1.41521.TCP.ubuntu22.04.amd64.deb"
gtb18="GTBEndpointAgent-15.19.1.41521.TCP.ubuntu18.04.amd64.deb"



isZscalerInstall=0
isCortexInstall=0
isMcAfeeTPInstall=0
isChromeInstall=0
isTeamsInstall=0
isOutlookInstall=0
isGlobalProtectInstall=0
version=0
isManageEngineInstall=0
isGtbInstall=0

zscalerDeps="install libglib2.0-0 net-tools libqt5dbus5 libqt5core5a libqt5gui5 libqt5opengl5 libqt5qml5 libqt5quick5 libqt5quickcontrols2-5 libqt5quickparticles5 libqt5quickwidgets5 libqt5sql5 libqt5sql5-sqlite libqt5webchannel5 libqt5webengine5 libqt5webenginecore5 libqt5webenginewidgets5 libqt5webkit5 libqt5webview5 libqt5widgets5 dbus libdbus-glib-1-2 libnss3-tools libnss-resolve curl jq systemd-coredump ca-certificates"

function updatingUpgrading(){

  while true

    do
   echo $yellow_on Taking $1 please wait $yellow_off && if { sudo apt $1 -y 2>&1 || echo E: update failed; } > log.txt; cat log.txt | grep -q '^[WE]:'; then
      cat log.txt
      echo
      echo Fetching files Please wait!!!
    else 
    echo
        echo "$yellow_on Pacakeges have been downloaded $yellow_off"
        echo "$green_on $1 completed $green_off"
        echo
        break
    
    fi
  done

}

function addProxy(){
  echo "$yellow_on Adding proxies $yellow_off"
  sudo tee -a /etc/environment <<< $1
  sudo tee -a /etc/apt/apt.conf <<< $2
  echo "$green_onProxies have been added successfully $green_off"
}

function removeProxy(){
  echo "$yellow_on Removing proxies $yellow_off"
  sed -i '$d' /etc/environment
  sed -i '$d' /etc/environment
  sed -i '$d' /etc/apt/apt.conf
  sed -i '$d' /etc/apt/apt.conf
  echo "$green_on Proxies have been removed successfully $green_off"
}

function installGpd5(){
  if { dpkg --get-selections; } | grep -qi "globalprotect"; then
#  if ( dpkg --get-selections; ) | grep -w "globalprotect"
#    then
    echo $green_on installed $green_off
    isGlobalProtectInstall=1
 else   
      echo $yellow_on globalprotect is not installed $yellow_off
      echo "Installing ${green_on} Globalprotect5... ${green_off}"
      updatingUpgrading "install libqt5webkit5"
      if { sudo dpkg -i $(pwd)/$gp5 2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isGlobalProtectInstall=0
        else
         isGlobalProtectInstall=1
         #echo "password" | globalprotect import-certificate --location $(pwd)/HIPS_Linux.p12 
          sudo tee -a /etc/cron.d/import_gpd_cert <<< "@reboot sleep 15 && echo "password" | globalprotect import-certificate --location /opt/paloaltonetworks/globalprotect/HIPS_Linux.p12"
      fi
     
 fi



}

function installGpd6(){
if ( dpkg --get-selections; ) | grep -w "globalprotect"
   then
    echo $green_on installed $green_off
    isGlobalProtectInstall=1
 else   
      echo $yellow_on globalprotect is not installed $yellow_off
      echo "Installing ${green_on} Globalprotect6... ${green_off}"
      updatingUpgrading "install libqt5webkit5"
      if { sudo dpkg -i $(pwd)/$gp6  2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isGlobalProtectInstall=0
        else
         isGlobalProtectInstall=1
         #echo "password" | globalprotect import-certificate --location $(pwd)/HIPS_Linux.p12 
         sudo tee -a /etc/cron.d/import_gpd_cert <<< "@reboot root /bin/sh -c 'sleep 15 && echo "password" | globalprotect import-certificate --location /opt/paloaltonetworks/globalprotect/HIPS_Linux.p12'"
      fi
      
 fi

}

function installCortex(){


if ( dpkg --get-selections; ) | grep -w "cortex-agent"
   then
    echo $green_on installed $green_off
    isCortexInstall=1 
 else   
      echo $yellow_on cortex is not installed $yellow_off
      echo "Installing ${green_on} Cortex... ${green_off}"
      sudo mkdir -p /etc/panw
      sudo cp $(pwd)/cortex.conf /etc/panw/
      if { sudo dpkg -i $(pwd)/$cortex 2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isCortexInstall=0
        else
         isCortexInstall=1 
      fi
 fi

}
function installGtb(){
  source /etc/lsb-release
case $DISTRIB_RELEASE in
18.04)
     gtb="gtb18"
;;
20.04)
    gtb="gtb20"
;;
22.04)
    gtb="gtb22"
;;
*)
    echo
;;
esac

if ( dpkg --get-selections; ) | grep -w "gtbendpointagent"
   then
    echo $green_on installed $green_off
    isGtbInstall=1 
 else   
      echo $yellow_on gtbendpointagent is not installed $yellow_off
      echo "Installing ${green_on} gtbendpointagent... ${green_off}"
      if { sudo dpkg -i $(pwd)/GTB/Ubuntu$DISTRIB_RELEASE/"${!gtb}" 2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isGtbInstall=0
        else
         isGtbInstall=1 
      fi
 fi

}

function installZscaler(){
  echo "$yellow_on Installing Zscaler Dependencies... $yellow_off"
  updatingUpgrading "${zscalerDeps}"
  echo 
  echo "$yellow_on Installing Zscaler... $yellow_off "
sudo chmod +x $(pwd)/$zscaler
sudo $(pwd)/$zscaler --mode unattended

if cat /var/log/zscaler/zscaler-installation.log | grep -w "Exiting with code 0"
then
    echo $green_on installed $green_off
    isZscalerInstall=1
 else   
    echo $yellow_on not installed $yellow_off
    isZscalerInstall=0
fi

}

function checkInstallation(){
  if [ $1 = 1 ]
    then
      echo "$green_on $2 is Installed $green_off"
      echo
  else
    echo "$yellow_on $2 is not Installed $yellow_off"
    echo
  fi
}

function usbBlock(){
  echo "$yellow_onInstalling USB block script... $yellow_off"
sudo chmod 777 $(pwd)/USB_Block.sh
sudo $(pwd)/USB_Block.sh
}

function installManageEngine(){
  echo "$yellow_on Installing ManageEngine... $yellow_off"
sudo chmod 777  $(pwd)/UEMS_LinuxAgent.bin
sudo $(pwd)/UEMS_LinuxAgent.bin
isManageEngineInstall=1
}

function installMcAfeeTP(){
  if ( dpkg --get-selections; ) | grep -w "mcafeetp"
   then
    echo "$green_on installed $green_off"
    isMcAfeeTPInstall=1
 else   
      echo $yellow_on McAfeeTP is not installed $yellow_off
      echo "Installing ${green_on} McAfeeTP... ${green_off}"
      sudo tar -xvf $(pwd)/$mcAfeeTP
      sudo $(pwd)/install-mfetp.sh
      isMcAfeeTPInstall=1 
      
 fi
 
}

function installTrellix(){

 if ( dpkg --get-selections; ) | grep -w "mfecma"
   then
    echo installed
    isTrellixInstall=1
 else   
      echo Trellix is not installed
      echo "Installing ${green_on} Trellix... ${green_off}"
      sudo chmod 777 $(pwd)/install-trellix.sh
      sudo $(pwd)/install-trellix.sh -i
      isTrellixInstall=1
      
 fi
}

# function installMcAfeeFW(){
#   echo "$green_on Installing McAfeeFW... $green_off"
#   sudo tar -xvf $(pwd)/$mcAfeeFW
# sudo $(pwd)/install-mfefw.sh
# isMcAfeeFWInstall=1
# }

function joinDomain(){
  echo "$green_on Joining Domain $green_off"
  #updatingUpgrading "install dnsmasq ssh vim realmd libnss-sss libpam-sss sssd sssd-tools adcli oddjob oddjob-mkhomedir packagekit samba-common-bin"
  sudo chmod 777 $linuxDomain
  sudo ./$linuxDomain

}

function installGooglechrome(){
if ( dpkg --get-selections; ) | grep -w "google-chrome-stable"
   then
    echo installed
    isChromeInstall=1
 else   
      echo chrome is not installed
      echo "${green_on} Installing Chrome... ${green_off}"
      if { sudo dpkg -i $(pwd)/$chrome 2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isChromeInstall=0
        else
         isChromeInstall=1 
      fi
 fi

}
function installEdge(){
if ( dpkg --get-selections; ) | grep -w "microsoft-edge-stable"
   then
    echo installed
    isEdgeInstall=1
 else   
      echo edge is not installed
      echo "${green_on}Installing Edge... ${green_off}"
      if { sudo dpkg -i $(pwd)/$msEdge 2>&1; } > log.txt; cat log.txt | grep -q "Errors"; then
        isEdgeInstall=0
        else
         isEdgeInstall=1 
      fi
 fi

}

function installTeams(){
if ( snap list; ) | grep -w "teams-for-linux"
then
    echo installed
 else   
    echo Teams is not installed
    echo "${green_on}Installing Teams... ${green_off}"
    sudo snap install teams-for-linux
    
fi
isTeamsInstall=1
}

function installOutlook(){
 
if ( snap list; ) | grep -w "outlook-for-linux"
then
    echo installed
 else   
    echo Outlook is not installed
     echo "${green_on}Installing Outlook... ${green_off}"
    sudo snap install outlook-for-linux --edge
fi
isOutlookInstall=1
}




function installShFiles(){
  echo "------------------Installing SH file-----------------------------"
  sudo chmod 777 $(pwd)/$1
sudo $(pwd)/$1
}

function installDebFiles(){
  echo "------------------Installing DEB file-----------------------------"
  sudo chmod 777 $(pwd)/$1
sudo dpkg -i $(pwd)/$1
}

function updateUpgrade(){
  echo "$yellow_on Checking for the updates $yellow_off"
updatingUpgrading "update"
echo "$yellow_on Upgrading the sysytem $yellow_off"
updatingUpgrading "upgrade"


}

while true; do
echo "Security Tools installation"
echo "Select a software to install:"
echo "1. Install McAfee TP"
echo "2. Install CortexXDR"
echo "3. Install Zscaler"
echo "4. Install USB_Block"
echo "5. Install ManageEngine"
echo "6. Install GlobalProtect 5"
echo "7. Install GlobalProtect 6"
echo "8. Install GoogleChrome"
echo "9. Install MSEdge"
echo "10. Install All Security Tools (LAPTOP)"
echo "11. Install All Security Tools (DESKTOP)"
echo "12. Join Domain"
echo "13. Install File"
echo "14. Install Trellix"
echo "15. Proxy Configuration"
echo "16. Post Install"
echo "17. Install GTB Agent"
echo "18. Exit"


read -p "Enter your choice (1/2/3/4/5/6/7/8/9/10/11/12/13/14/15/16): " choice

case $choice in
1)
  installTrellix
  installMcAfeeTP
  wait
;;
2)
  #checkInstallation $isCortexInstall "Cortex"
  installCortex
  #checkInstallation $isCortexInstall "Cortex"
  wait
;;
3)
  installZscaler
  wait
;;
4)
  usbBlock
  wait
;;
5)
  installManageEngine
  wait
;;

6)
  #checkInstallation $isGlobalProtectInstall "Global Protect"
  installGpd5
  #checkInstallation $isGlobalProtectInstall "Global Protect"
;;
7)
  #checkInstallation $isGlobalProtectInstall "Global Protect"
  installGpd6
  #checkInstallation $isGlobalProtectInstall "Global Protect"
;;
8)
  #checkInstallation $isChromeInstall "Chrome"
  installGooglechrome
  #checkInstallation $isChromeInstall "Chrome"
;;
9)
  #checkInstallation $isEdgeInstall "Edge"
  installEdge
  #checkInstallation $isEdgeInstall "Edge"
;;

10)
echo
echo "Accessing jira, confluence[y/n]?"
  read -p "Answer[y/n]: " ans
 echo
echo "Dell laptop[y/n]?"
  read -p "Answer: " laptop
  echo
  echo "Want to add in domain[y/n]?"
  read -p "Answer[y/n]: " domain
  echo
  updateUpgrade
  wait
  echo
  installTrellix
  wait
  echo
  installCortex
  wait
  echo
  installGtb
  wait
  echo
  installManageEngine
  wait
  echo
  installMcAfeeTP
  wait
  echo
  # installMcAfeeFW
  # wait
  # echo
  

 if [ "${laptop,,}" = "yes" ] || [ "${laptop,,}" = "y" ]
  then
    updatingUpgrading "install linux-modules-iwlwifi-generic-hwe-20.04"
    echo
fi

installGooglechrome
wait
echo
installEdge
echo
installTeams
wait
echo
installOutlook
wait
echo
installZscaler
wait
  if [ "${ans,,}" = "yes" ] || [ "${ans,,}" = "y" ]
    then
      installGpd6
      echo
  else
    installGpd5
    echo
  fi
echo
for val in isZscalerInstall isGtbInstall isChromeInstall isCortexInstall isManageEngineInstall isGlobalProtectInstall isMcAfeeTPInstall isOutlookInstall isTeamsInstall isTrellixInstall
do  
    if [ "${!val}" = 0 ] 
    then 
        val=$( echo $val | sed s/"is"// )
        val=$( echo $val | sed s/"Install"// )
        echo $yellow_on $val is  not installed $yellow_off
        echo
    else
        val=$( echo $val | sed s/"is"// )
        val=$( echo $val | sed s/"Install"// ) 
        echo $green_on $val is installed $green_off
        echo
    fi
    sleep 1
done
if [ "${domain,,}" = "yes" ] || [ "${domain,,}" = "y" ]
  then
    joinDomain
    echo
fi

;;

11)
echo
echo "Panasonic desktop?"
  read -p "Answer[y/n]: " ans
  echo
 echo "Want to add in domain[y/n]?"
  read -p "Answer[y/n]: " domain
  echo
  
updateUpgrade
wait
echo
  installTrellix
  wait
  echo
  installCortex
  wait
  echo
  installGtb
  wait
  echo
  installManageEngine
  wait
  echo
  installMcAfeeTP
  wait
  echo
  # installMcAfeeFW
  # wait
  # echo

installGooglechrome
echo
installTeams
installOutlook
installEdge
echo
 if [ "${ans,,}" = "no" ] || [ "${ans,,}" = "n" ]
  then
    installZscaler
    echo
fi

echo
updatingUpgrading "install xrdp openssh-server"
wait
echo

for val in isZscalerInstall isGtbInstall isChromeInstall isCortexInstall isManageEngineInstall isMcAfeeTPInstall isOutlookInstall isTrellixInstall
do  
    if [ "${!val}" = 0 ] 
    then 
        val=$( echo $val | sed s/"is"// )
        val=$( echo $val | sed s/"Install"// )
        echo $yellow_on $val is  not installed $yellow_off
        echo
    else
        val=$( echo $val | sed s/"is"// )
        val=$( echo $val | sed s/"Install"// ) 
        echo $green_on $val is installed $green_off
        echo
    fi
    sleep 1
done
 addProxy "$GEN_ENV_PROXY" "$GEN_APT_PROXY"
    echo
    sudo shutdown +1
if [ "${domain,,}" = "yes" ] || [ "${domain,,}" = "y" ]
  then
    joinDomain
    echo
fi
;;

12)
joinDomain
;;

13)
echo "Insert the complete file name with it's extention: "
echo "Files with no extension keep as it is"
echo "e.g - <filename>.deb / <filename>.sh / <filename>"
read fileName
echo $fileName
if { file $fileName; } | grep -qi "Debian binary package"; then
echo "Installing deb file"
  installDebFiles "$fileName"
elif { file $fileName; } | grep -qi "Bourne-Again shell script,"; then
echo "Installing sh file"
  installShFiles "$fileName -i"
elif { file $fileName; } | grep -qi "Bourne-Again shell script executable"; then
  installShFiles "$fileName"
elif { file $fileName; } | grep -qi "ELF 64-bit LSB"; then
echo "Installing ELF exe file"
  installShFiles "$fileName"
else
  echo "file doesn't support!!!!. Please check file once. For more info"
  echo
  file $fileName
fi

;;
14)
  installTrellix
;;

15)
  echo
  echo "Select Operation"
  echo "1. Add proxies"
  echo "2. Remove proxies"
  read -p "Enter choice: " choice

 case $choice in
 1)
  echo "Panasonic desktop?"
  read -p "Answer[y/n]: " ans
  echo
  if [ "${ans,,}" = "yes" ] || [ "${ans,,}" = "y" ]
  then
    addProxy "$PANA_ENV_PROXY" "$PANA_APT_PROXY"
    echo
fi
if [ "${ans,,}" = "no" ] || [ "${ans,,}" = "n" ]
  then
    addProxy "$GEN_ENV_PROXY" "$GEN_APT_PROXY"
    echo
fi
 ;;
 2)
  removeProxy
 ;;
 *)
  echo "Invalid choice."
 ;;
 esac


;;

16)
  echo
  echo "Post Installation"
  sudo chmod 777 post-install.sh
  sudo ./post-install.sh
;;
17)
  installGtb
;;

18)
echo "Exiting the script. Goodbye!" 
sudo rm log.txt
exit 0 

;;

*)
 echo "Invalid choice. Please enter a number between 1 and 17." continue 

;; 

esac


  read -p "Do you want to install another software? (yes/no): " continue_installation



  if [ "${continue_installation,,}" = "no" ] || [ "${continue_installation,,}" = "n" ]
  then
    sudo rm log.txt
    echo "Exiting the script. Goodbye!"

     exit 0

  fi


done
